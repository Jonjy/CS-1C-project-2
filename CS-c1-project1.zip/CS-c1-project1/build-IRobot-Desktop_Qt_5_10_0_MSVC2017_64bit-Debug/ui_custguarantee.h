/********************************************************************************
** Form generated from reading UI file 'custguarantee.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CUSTGUARANTEE_H
#define UI_CUSTGUARANTEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_custGuarantee
{
public:
    QTextEdit *MoneyBackG;
    QPushButton *contactUs;
    QPushButton *main;
    QLabel *ThumbLabel;

    void setupUi(QWidget *custGuarantee)
    {
        if (custGuarantee->objectName().isEmpty())
            custGuarantee->setObjectName(QStringLiteral("custGuarantee"));
        custGuarantee->resize(674, 472);
        custGuarantee->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        MoneyBackG = new QTextEdit(custGuarantee);
        MoneyBackG->setObjectName(QStringLiteral("MoneyBackG"));
        MoneyBackG->setGeometry(QRect(10, 10, 411, 451));
        QFont font;
        font.setPointSize(10);
        MoneyBackG->setFont(font);
        MoneyBackG->setStyleSheet(QStringLiteral("background-color:white;"));
        MoneyBackG->setReadOnly(true);
        contactUs = new QPushButton(custGuarantee);
        contactUs->setObjectName(QStringLiteral("contactUs"));
        contactUs->setGeometry(QRect(530, 390, 131, 23));
        contactUs->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        main = new QPushButton(custGuarantee);
        main->setObjectName(QStringLiteral("main"));
        main->setGeometry(QRect(530, 440, 131, 23));
        main->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        ThumbLabel = new QLabel(custGuarantee);
        ThumbLabel->setObjectName(QStringLiteral("ThumbLabel"));
        ThumbLabel->setGeometry(QRect(430, 10, 231, 251));
        ThumbLabel->setPixmap(QPixmap(QString::fromUtf8(":/images/thumb.jpg")));

        retranslateUi(custGuarantee);

        QMetaObject::connectSlotsByName(custGuarantee);
    } // setupUi

    void retranslateUi(QWidget *custGuarantee)
    {
        custGuarantee->setWindowTitle(QApplication::translate("custGuarantee", "Customer Guarantee", nullptr));
        MoneyBackG->setHtml(QApplication::translate("custGuarantee", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#3a65ff;\">90 Day Money Back Guarantee! </span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#000000;\">Sleep comfortably knowing that if you are not 100% satisfied with your new robot, you have 90 days to return the robot back to us. You can do this by selecting the &quot;contact us&quot;  button below!</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right"
                        ":0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#0055ff;\">Return Procedure</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#000000;\">Simply click the &quot;contact&quot; us button below and let us know the reason why you want a return. </span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#0055ff;\">Our Promise</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#000000;\">iRobots is dedicated to the design and manufacture of our highly functional  robots with 100% effectiveness in detecting bombs.We just know that you are going to love your robot and we guarantee customer satisfaction 100%. However, we prom"
                        "ise that if you are not 100% happy with your robot, our team will help  make your return easy.</span></p></body></html>", nullptr));
        contactUs->setText(QApplication::translate("custGuarantee", "Contact us ", nullptr));
        main->setText(QApplication::translate("custGuarantee", "Return to Main", nullptr));
        ThumbLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class custGuarantee: public Ui_custGuarantee {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CUSTGUARANTEE_H
