/********************************************************************************
** Form generated from reading UI file 'contactus.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONTACTUS_H
#define UI_CONTACTUS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ContactUs
{
public:
    QTextEdit *textEdit;
    QComboBox *comboBox;
    QTextEdit *custEditBox;
    QPushButton *submit;
    QPushButton *cancel;
    QGroupBox *groupBox;
    QLineEdit *name;
    QLabel *nameLabel;
    QLabel *emailLabel;
    QLineEdit *email;
    QLabel *briefMessageLabel;

    void setupUi(QWidget *ContactUs)
    {
        if (ContactUs->objectName().isEmpty())
            ContactUs->setObjectName(QStringLiteral("ContactUs"));
        ContactUs->resize(469, 372);
        ContactUs->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        textEdit = new QTextEdit(ContactUs);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(10, 10, 451, 31));
        QFont font;
        font.setPointSize(10);
        textEdit->setFont(font);
        textEdit->setStyleSheet(QLatin1String("background: transparent;\n"
"border:0px;"));
        textEdit->setReadOnly(true);
        comboBox = new QComboBox(ContactUs);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(10, 50, 451, 31));
        comboBox->setFont(font);
        comboBox->setStyleSheet(QStringLiteral("background-color: white;"));
        custEditBox = new QTextEdit(ContactUs);
        custEditBox->setObjectName(QStringLiteral("custEditBox"));
        custEditBox->setGeometry(QRect(10, 200, 451, 131));
        custEditBox->setFont(font);
        custEditBox->setStyleSheet(QStringLiteral("background-color: white;"));
        submit = new QPushButton(ContactUs);
        submit->setObjectName(QStringLiteral("submit"));
        submit->setGeometry(QRect(180, 340, 75, 23));
        submit->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        cancel = new QPushButton(ContactUs);
        cancel->setObjectName(QStringLiteral("cancel"));
        cancel->setGeometry(QRect(380, 340, 75, 23));
        cancel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        groupBox = new QGroupBox(ContactUs);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 90, 451, 61));
        name = new QLineEdit(groupBox);
        name->setObjectName(QStringLiteral("name"));
        name->setGeometry(QRect(10, 30, 191, 25));
        name->setFont(font);
        name->setStyleSheet(QStringLiteral("background-color: white;"));
        nameLabel = new QLabel(groupBox);
        nameLabel->setObjectName(QStringLiteral("nameLabel"));
        nameLabel->setGeometry(QRect(10, 10, 141, 16));
        nameLabel->setFont(font);
        emailLabel = new QLabel(groupBox);
        emailLabel->setObjectName(QStringLiteral("emailLabel"));
        emailLabel->setGeometry(QRect(210, 10, 141, 16));
        emailLabel->setFont(font);
        email = new QLineEdit(groupBox);
        email->setObjectName(QStringLiteral("email"));
        email->setGeometry(QRect(210, 30, 231, 25));
        email->setFont(font);
        email->setStyleSheet(QStringLiteral("background-color: white;"));
        briefMessageLabel = new QLabel(ContactUs);
        briefMessageLabel->setObjectName(QStringLiteral("briefMessageLabel"));
        briefMessageLabel->setGeometry(QRect(10, 170, 451, 21));
        briefMessageLabel->setFont(font);

        retranslateUi(ContactUs);

        QMetaObject::connectSlotsByName(ContactUs);
    } // setupUi

    void retranslateUi(QWidget *ContactUs)
    {
        ContactUs->setWindowTitle(QApplication::translate("ContactUs", "Contact Us", nullptr));
        textEdit->setHtml(QApplication::translate("ContactUs", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:8.25pt;\">Help us narrrow down your problem by selecting a field below? </span></p></body></html>", nullptr));
        comboBox->setItemText(0, QApplication::translate("ContactUs", "Request more info", nullptr));
        comboBox->setItemText(1, QApplication::translate("ContactUs", "I never got my Robot? ", nullptr));
        comboBox->setItemText(2, QApplication::translate("ContactUs", "Problem with iRobot?  ", nullptr));
        comboBox->setItemText(3, QApplication::translate("ContactUs", "Other", nullptr));

        submit->setText(QApplication::translate("ContactUs", "Submit", nullptr));
        cancel->setText(QApplication::translate("ContactUs", "Cancel", nullptr));
        groupBox->setTitle(QString());
        name->setText(QString());
        nameLabel->setText(QApplication::translate("ContactUs", "Enter Full Name*", nullptr));
        emailLabel->setText(QApplication::translate("ContactUs", "Enter Email*", nullptr));
        email->setText(QString());
        briefMessageLabel->setText(QApplication::translate("ContactUs", "Leave a Brief Message explaining your problems/questions:  ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ContactUs: public Ui_ContactUs {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONTACTUS_H
