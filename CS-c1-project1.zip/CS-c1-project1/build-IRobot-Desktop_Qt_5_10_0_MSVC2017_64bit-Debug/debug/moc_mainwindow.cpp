/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../IRobot/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[28];
    char stringdata0[516];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 10), // "adminLogin"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 13), // "customerLogin"
QT_MOC_LITERAL(4, 37, 6), // "logout"
QT_MOC_LITERAL(5, 44, 12), // "viewProducts"
QT_MOC_LITERAL(6, 57, 8), // "contacts"
QT_MOC_LITERAL(7, 66, 13), // "viewGuarantee"
QT_MOC_LITERAL(8, 80, 4), // "help"
QT_MOC_LITERAL(9, 85, 15), // "requestPamphlet"
QT_MOC_LITERAL(10, 101, 16), // "viewCustomerList"
QT_MOC_LITERAL(11, 118, 8), // "populate"
QT_MOC_LITERAL(12, 127, 11), // "addCustomer"
QT_MOC_LITERAL(13, 139, 12), // "editCustomer"
QT_MOC_LITERAL(14, 152, 14), // "deleteCustomer"
QT_MOC_LITERAL(15, 167, 11), // "viewReviews"
QT_MOC_LITERAL(16, 179, 3), // "key"
QT_MOC_LITERAL(17, 183, 15), // "breakEverything"
QT_MOC_LITERAL(18, 199, 38), // "on_RPMainRequestPamphletButto..."
QT_MOC_LITERAL(19, 238, 25), // "on_RPSubmitButton_clicked"
QT_MOC_LITERAL(20, 264, 19), // "on_opButton_clicked"
QT_MOC_LITERAL(21, 284, 29), // "on_opReturnMainButton_clicked"
QT_MOC_LITERAL(22, 314, 32), // "on_viewOrdersAdminButton_clicked"
QT_MOC_LITERAL(23, 347, 41), // "on_ovCompanyNameCombo_current..."
QT_MOC_LITERAL(24, 389, 32), // "on_ovSortByOrderIDButton_clicked"
QT_MOC_LITERAL(25, 422, 29), // "on_ovSortByNameButton_clicked"
QT_MOC_LITERAL(26, 452, 25), // "on_ovReturnButton_clicked"
QT_MOC_LITERAL(27, 478, 37) // "on_ovOrderIDCombo_currentInde..."

    },
    "MainWindow\0adminLogin\0\0customerLogin\0"
    "logout\0viewProducts\0contacts\0viewGuarantee\0"
    "help\0requestPamphlet\0viewCustomerList\0"
    "populate\0addCustomer\0editCustomer\0"
    "deleteCustomer\0viewReviews\0key\0"
    "breakEverything\0on_RPMainRequestPamphletButton_clicked\0"
    "on_RPSubmitButton_clicked\0on_opButton_clicked\0"
    "on_opReturnMainButton_clicked\0"
    "on_viewOrdersAdminButton_clicked\0"
    "on_ovCompanyNameCombo_currentIndexChanged\0"
    "on_ovSortByOrderIDButton_clicked\0"
    "on_ovSortByNameButton_clicked\0"
    "on_ovReturnButton_clicked\0"
    "on_ovOrderIDCombo_currentIndexChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  144,    2, 0x0a /* Public */,
       3,    0,  145,    2, 0x0a /* Public */,
       4,    0,  146,    2, 0x0a /* Public */,
       5,    0,  147,    2, 0x0a /* Public */,
       6,    0,  148,    2, 0x0a /* Public */,
       7,    0,  149,    2, 0x0a /* Public */,
       8,    0,  150,    2, 0x0a /* Public */,
       9,    0,  151,    2, 0x0a /* Public */,
      10,    0,  152,    2, 0x0a /* Public */,
      11,    0,  153,    2, 0x0a /* Public */,
      12,    0,  154,    2, 0x0a /* Public */,
      13,    0,  155,    2, 0x0a /* Public */,
      14,    0,  156,    2, 0x0a /* Public */,
      15,    0,  157,    2, 0x0a /* Public */,
      16,    0,  158,    2, 0x0a /* Public */,
      17,    0,  159,    2, 0x0a /* Public */,
      18,    0,  160,    2, 0x0a /* Public */,
      19,    0,  161,    2, 0x0a /* Public */,
      20,    0,  162,    2, 0x08 /* Private */,
      21,    0,  163,    2, 0x08 /* Private */,
      22,    0,  164,    2, 0x08 /* Private */,
      23,    0,  165,    2, 0x08 /* Private */,
      24,    0,  166,    2, 0x08 /* Private */,
      25,    0,  167,    2, 0x08 /* Private */,
      26,    0,  168,    2, 0x08 /* Private */,
      27,    0,  169,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->adminLogin(); break;
        case 1: _t->customerLogin(); break;
        case 2: _t->logout(); break;
        case 3: _t->viewProducts(); break;
        case 4: _t->contacts(); break;
        case 5: _t->viewGuarantee(); break;
        case 6: _t->help(); break;
        case 7: _t->requestPamphlet(); break;
        case 8: _t->viewCustomerList(); break;
        case 9: _t->populate(); break;
        case 10: _t->addCustomer(); break;
        case 11: _t->editCustomer(); break;
        case 12: _t->deleteCustomer(); break;
        case 13: _t->viewReviews(); break;
        case 14: _t->key(); break;
        case 15: _t->breakEverything(); break;
        case 16: _t->on_RPMainRequestPamphletButton_clicked(); break;
        case 17: _t->on_RPSubmitButton_clicked(); break;
        case 18: _t->on_opButton_clicked(); break;
        case 19: _t->on_opReturnMainButton_clicked(); break;
        case 20: _t->on_viewOrdersAdminButton_clicked(); break;
        case 21: _t->on_ovCompanyNameCombo_currentIndexChanged(); break;
        case 22: _t->on_ovSortByOrderIDButton_clicked(); break;
        case 23: _t->on_ovSortByNameButton_clicked(); break;
        case 24: _t->on_ovReturnButton_clicked(); break;
        case 25: _t->on_ovOrderIDCombo_currentIndexChanged(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 26;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
