/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QStackedWidget *stackedWidget;
    QWidget *Login;
    QLabel *label_15;
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout;
    QLineEdit *passwordLine;
    QLineEdit *CompanyNameLine;
    QLabel *label;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_12;
    QSpacerItem *verticalSpacer_11;
    QSpacerItem *verticalSpacer_13;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *pushButton_9;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *pushButton;
    QWidget *customer;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_7;
    QSpacerItem *verticalSpacer_8;
    QLabel *helpLabel1;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_5;
    QPushButton *opButton;
    QPushButton *pushButton_6;
    QSpacerItem *verticalSpacer_2;
    QLabel *helpLabel2;
    QLabel *helpLabel5;
    QLabel *helpLabel6;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_6;
    QLabel *helpLabel3;
    QSpacerItem *verticalSpacer_4;
    QLabel *helpLabel7;
    QLabel *helpLabel4;
    QPushButton *pushButton_8;
    QPushButton *pushButton_3;
    QPushButton *pushButton_5;
    QPushButton *pushButton_20;
    QSpacerItem *verticalSpacer_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_16;
    QLabel *CompanyLabel;
    QTextBrowser *pitchWindow;
    QWidget *Admin;
    QTextEdit *textEdit;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton_10;
    QPushButton *viewOrdersAdminButton;
    QPushButton *pushButton_4;
    QWidget *operations;
    QPushButton *opReturnMainButton;
    QLabel *opPageTitle;
    QGroupBox *opDisposalGroup;
    QLabel *opDisposalImage;
    QTextEdit *opDisposalText;
    QGroupBox *opDetectGroup;
    QTextEdit *opDetectText;
    QLabel *opDetectImage;
    QGroupBox *opEnvironGroup;
    QTextEdit *opOneText;
    QLabel *opEnvironImage;
    QLabel *opEnvironText;
    QWidget *RequestPamphlet;
    QTextEdit *RPTextEdit;
    QGroupBox *RPgroupBox;
    QLineEdit *RPCompanyNamelineEdit;
    QLabel *RPCompanyNameLabel;
    QLineEdit *RPAddressOneLineEdit;
    QLineEdit *RPAddressTwoLineEdit;
    QLabel *RPAddressL1Label;
    QLabel *RPAddressL2Label;
    QComboBox *RPInterestcomboBox;
    QLabel *PRinterestLabel;
    QPushButton *RPMainRequestPamphletButton;
    QPushButton *RPSubmitButton;
    QLabel *label_3;
    QWidget *CustomerViewer;
    QTableView *tableView;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_16;
    QPushButton *pushButton_11;
    QPushButton *pushButton_17;
    QPushButton *keyButton;
    QPushButton *pushButton_12;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QComboBox *comboBox;
    QLabel *label_5;
    QLineEdit *companyEdit;
    QLabel *label_6;
    QLineEdit *addressEdit;
    QLabel *label_7;
    QLineEdit *InterestEdit;
    QLabel *label_8;
    QLineEdit *keyEdit;
    QWidget *OrderViewer;
    QGroupBox *OrderDetailGroupBox;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *ovCompanyNameLabel;
    QComboBox *ovCompanyNameCombo;
    QWidget *layoutWidget2;
    QFormLayout *formLayout;
    QLabel *OrderIDLabel;
    QComboBox *ovOrderIDCombo;
    QLabel *RobotAQtyLabel;
    QLineEdit *ovRobotAQty;
    QLabel *RobotAPlanLabel;
    QLineEdit *ovRobotAPlan;
    QLabel *RibotBQtyLabel;
    QLineEdit *ovRobotBQty;
    QLabel *RobotBPlanLabel;
    QLineEdit *ovRobotBPlan;
    QLabel *RobotCQtyLabel;
    QLineEdit *ovRobotCQty;
    QLabel *RobotCPlanLabel;
    QLineEdit *ovRobotCPlan;
    QLabel *RobotASubLabel;
    QLineEdit *ovRobotASub;
    QLabel *RobotBSubLabel;
    QLineEdit *ovRobotBSub;
    QLabel *RobotCSubLabel;
    QLineEdit *ovRobotCSub;
    QLabel *SubtotalLabel;
    QLineEdit *ovSubtotal;
    QLabel *ShippingLabel;
    QLineEdit *ovShipping;
    QLabel *SalesTaxLabel;
    QLineEdit *ovSalesTax;
    QLabel *TotalPriceLabel;
    QLineEdit *ovTotalPrice;
    QSpacerItem *verticalSpacer_10;
    QSpacerItem *verticalSpacer_9;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout_5;
    QSpacerItem *verticalSpacer_7;
    QSpacerItem *verticalSpacer_15;
    QSpacerItem *verticalSpacer_16;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *ovSortByOrderIDButton;
    QPushButton *ovSortByNameButton;
    QPushButton *ovReturnButton;
    QSpacerItem *horizontalSpacer_9;
    QTableView *ovTable;
    QWidget *page;
    QLabel *label_23;
    QPushButton *pushButton_21;
    QPushButton *pushButton_18;
    QGroupBox *groupBox_2;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_12;
    QWidget *layoutWidget4;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_9;
    QTextEdit *textEdit_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(943, 631);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setSizeIncrement(QSize(0, 0));
        MainWindow->setStyleSheet(QStringLiteral("background-color: #808080;"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        stackedWidget = new QStackedWidget(centralWidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 10, 961, 571));
        stackedWidget->setStyleSheet(QStringLiteral(""));
        Login = new QWidget();
        Login->setObjectName(QStringLiteral("Login"));
        Login->setStyleSheet(QStringLiteral("background-image: url(:/images/waleegrass.png);"));
        label_15 = new QLabel(Login);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(460, 140, 461, 71));
        label_15->setStyleSheet(QStringLiteral("background: transparent;"));
        label_15->setAlignment(Qt::AlignCenter);
        groupBox = new QGroupBox(Login);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(460, 270, 471, 251));
        groupBox->setStyleSheet(QStringLiteral("background:rgba(255,255,255,.2)"));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 455, 231));
        gridLayout_3 = new QGridLayout(layoutWidget);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(6);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        passwordLine = new QLineEdit(layoutWidget);
        passwordLine->setObjectName(QStringLiteral("passwordLine"));
        passwordLine->setStyleSheet(QLatin1String("font-size : 14px;\n"
"color : black;\n"
"height : 25px;"));

        gridLayout->addWidget(passwordLine, 2, 1, 1, 1);

        CompanyNameLine = new QLineEdit(layoutWidget);
        CompanyNameLine->setObjectName(QStringLiteral("CompanyNameLine"));
        CompanyNameLine->setStyleSheet(QLatin1String("font-size : 14px;\n"
"color : black;\n"
"height : 25px;"));

        gridLayout->addWidget(CompanyNameLine, 1, 1, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"height : 25px;\n"
"width : 125px;"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label, 1, 0, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"height : 25px;\n"
"width : 125px;"));
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label_2, 2, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 0, 1, 3);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_12, 1, 0, 1, 1);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_11, 1, 1, 1, 1);

        verticalSpacer_13 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer_13, 1, 2, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout->addWidget(pushButton_2);

        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_7);

        pushButton_9 = new QPushButton(layoutWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 150px;\n"
"border: 2px solid black;"));

        horizontalLayout->addWidget(pushButton_9);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout->addWidget(pushButton);


        gridLayout_3->addLayout(horizontalLayout, 2, 0, 1, 3);

        stackedWidget->addWidget(Login);
        customer = new QWidget();
        customer->setObjectName(QStringLiteral("customer"));
        customer->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        gridLayoutWidget_2 = new QWidget(customer);
        gridLayoutWidget_2->setObjectName(QStringLiteral("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(10, 10, 937, 511));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_7 = new QPushButton(gridLayoutWidget_2);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_7, 10, 1, 1, 1);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_8, 9, 1, 1, 1);

        helpLabel1 = new QLabel(gridLayoutWidget_2);
        helpLabel1->setObjectName(QStringLiteral("helpLabel1"));

        gridLayout_2->addWidget(helpLabel1, 4, 2, 1, 1);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_3, 5, 1, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_5, 3, 1, 1, 1);

        opButton = new QPushButton(gridLayoutWidget_2);
        opButton->setObjectName(QStringLiteral("opButton"));
        opButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(opButton, 6, 1, 1, 1);

        pushButton_6 = new QPushButton(gridLayoutWidget_2);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_6, 12, 1, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_2, 7, 1, 1, 1);

        helpLabel2 = new QLabel(gridLayoutWidget_2);
        helpLabel2->setObjectName(QStringLiteral("helpLabel2"));

        gridLayout_2->addWidget(helpLabel2, 10, 2, 1, 1);

        helpLabel5 = new QLabel(gridLayoutWidget_2);
        helpLabel5->setObjectName(QStringLiteral("helpLabel5"));

        gridLayout_2->addWidget(helpLabel5, 16, 2, 1, 1);

        helpLabel6 = new QLabel(gridLayoutWidget_2);
        helpLabel6->setObjectName(QStringLiteral("helpLabel6"));

        gridLayout_2->addWidget(helpLabel6, 6, 2, 1, 1);

        verticalSpacer = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 15, 1, 1, 1);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_6, 13, 2, 1, 1);

        helpLabel3 = new QLabel(gridLayoutWidget_2);
        helpLabel3->setObjectName(QStringLiteral("helpLabel3"));

        gridLayout_2->addWidget(helpLabel3, 12, 2, 1, 1);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_4, 13, 1, 1, 1);

        helpLabel7 = new QLabel(gridLayoutWidget_2);
        helpLabel7->setObjectName(QStringLiteral("helpLabel7"));

        gridLayout_2->addWidget(helpLabel7, 8, 2, 1, 1);

        helpLabel4 = new QLabel(gridLayoutWidget_2);
        helpLabel4->setObjectName(QStringLiteral("helpLabel4"));

        gridLayout_2->addWidget(helpLabel4, 14, 2, 1, 1);

        pushButton_8 = new QPushButton(gridLayoutWidget_2);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_8, 14, 1, 1, 1);

        pushButton_3 = new QPushButton(gridLayoutWidget_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_3, 16, 1, 1, 1);

        pushButton_5 = new QPushButton(gridLayoutWidget_2);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_5, 4, 1, 1, 1);

        pushButton_20 = new QPushButton(gridLayoutWidget_2);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_2->addWidget(pushButton_20, 8, 1, 1, 1);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_6, 11, 1, 1, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_16 = new QLabel(gridLayoutWidget_2);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_4->addWidget(label_16);

        CompanyLabel = new QLabel(gridLayoutWidget_2);
        CompanyLabel->setObjectName(QStringLiteral("CompanyLabel"));

        horizontalLayout_4->addWidget(CompanyLabel);


        gridLayout_2->addLayout(horizontalLayout_4, 2, 1, 1, 1);

        pitchWindow = new QTextBrowser(customer);
        pitchWindow->setObjectName(QStringLiteral("pitchWindow"));
        pitchWindow->setGeometry(QRect(145, 25, 780, 505));
        pitchWindow->setStyleSheet(QLatin1String("background-color: white;\n"
"border:0px;\n"
"padding: 5px;\n"
"border-radius : 6px;"));
        stackedWidget->addWidget(customer);
        Admin = new QWidget();
        Admin->setObjectName(QStringLiteral("Admin"));
        Admin->setStyleSheet(QStringLiteral("background-color: #404040;"));
        textEdit = new QTextEdit(Admin);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(10, 30, 921, 101));
        textEdit->setStyleSheet(QLatin1String("background: transparent;\n"
"border: 0px;"));
        horizontalLayoutWidget_2 = new QWidget(Admin);
        horizontalLayoutWidget_2->setObjectName(QStringLiteral("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(210, 270, 561, 91));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_10 = new QPushButton(horizontalLayoutWidget_2);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_2->addWidget(pushButton_10);

        viewOrdersAdminButton = new QPushButton(horizontalLayoutWidget_2);
        viewOrdersAdminButton->setObjectName(QStringLiteral("viewOrdersAdminButton"));
        viewOrdersAdminButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_2->addWidget(viewOrdersAdminButton);

        pushButton_4 = new QPushButton(horizontalLayoutWidget_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_2->addWidget(pushButton_4);

        stackedWidget->addWidget(Admin);
        operations = new QWidget();
        operations->setObjectName(QStringLiteral("operations"));
        operations->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        opReturnMainButton = new QPushButton(operations);
        opReturnMainButton->setObjectName(QStringLiteral("opReturnMainButton"));
        opReturnMainButton->setGeometry(QRect(740, 525, 181, 28));
        opReturnMainButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        opPageTitle = new QLabel(operations);
        opPageTitle->setObjectName(QStringLiteral("opPageTitle"));
        opPageTitle->setGeometry(QRect(320, 0, 601, 51));
        QFont font;
        font.setPointSize(26);
        font.setBold(true);
        font.setWeight(75);
        opPageTitle->setFont(font);
        opPageTitle->setStyleSheet(QStringLiteral(""));
        opPageTitle->setAlignment(Qt::AlignCenter);
        opDisposalGroup = new QGroupBox(operations);
        opDisposalGroup->setObjectName(QStringLiteral("opDisposalGroup"));
        opDisposalGroup->setEnabled(true);
        opDisposalGroup->setGeometry(QRect(0, 350, 671, 200));
        opDisposalGroup->setStyleSheet(QLatin1String("border:0;\n"
"background: transparent;"));
        opDisposalGroup->setFlat(true);
        opDisposalImage = new QLabel(opDisposalGroup);
        opDisposalImage->setObjectName(QStringLiteral("opDisposalImage"));
        opDisposalImage->setGeometry(QRect(0, 0, 250, 200));
        opDisposalImage->setPixmap(QPixmap(QString::fromUtf8(":/images/bombdisposal.jpg")));
        opDisposalImage->setScaledContents(true);
        opDisposalText = new QTextEdit(opDisposalGroup);
        opDisposalText->setObjectName(QStringLiteral("opDisposalText"));
        opDisposalText->setGeometry(QRect(260, 59, 411, 141));
        opDisposalText->setMinimumSize(QSize(0, 0));
        opDisposalText->setStyleSheet(QStringLiteral("background-color: white;"));
        opDisposalText->setFrameShape(QFrame::StyledPanel);
        opDisposalText->setFrameShadow(QFrame::Sunken);
        opDisposalText->setLineWidth(1);
        opDisposalText->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        opDisposalText->setReadOnly(true);
        opDetectGroup = new QGroupBox(operations);
        opDetectGroup->setObjectName(QStringLiteral("opDetectGroup"));
        opDetectGroup->setGeometry(QRect(340, 240, 581, 271));
        opDetectGroup->setStyleSheet(QStringLiteral("border:0"));
        opDetectGroup->setFlat(true);
        opDetectText = new QTextEdit(opDetectGroup);
        opDetectText->setObjectName(QStringLiteral("opDetectText"));
        opDetectText->setGeometry(QRect(0, 0, 351, 141));
        opDetectText->setStyleSheet(QStringLiteral("background-color: white;"));
        opDetectText->setReadOnly(true);
        opDetectImage = new QLabel(opDetectGroup);
        opDetectImage->setObjectName(QStringLiteral("opDetectImage"));
        opDetectImage->setGeometry(QRect(360, 0, 221, 271));
        opDetectImage->setPixmap(QPixmap(QString::fromUtf8(":/images/detectbomb.PNG")));
        opDetectImage->setScaledContents(true);
        opDetectImage->raise();
        opDetectText->raise();
        opEnvironGroup = new QGroupBox(operations);
        opEnvironGroup->setObjectName(QStringLiteral("opEnvironGroup"));
        opEnvironGroup->setGeometry(QRect(-1, 0, 921, 341));
        opEnvironGroup->setStyleSheet(QStringLiteral("border:0"));
        opEnvironGroup->setFlat(true);
        opOneText = new QTextEdit(opEnvironGroup);
        opOneText->setObjectName(QStringLiteral("opOneText"));
        opOneText->setGeometry(QRect(320, 70, 461, 141));
        opOneText->setStyleSheet(QStringLiteral("background-color: white;"));
        opOneText->setReadOnly(true);
        opEnvironImage = new QLabel(opEnvironGroup);
        opEnvironImage->setObjectName(QStringLiteral("opEnvironImage"));
        opEnvironImage->setGeometry(QRect(0, 0, 311, 341));
        opEnvironImage->setPixmap(QPixmap(QString::fromUtf8(":/images/environment.PNG")));
        opEnvironImage->setScaledContents(true);
        opEnvironText = new QLabel(opEnvironGroup);
        opEnvironText->setObjectName(QStringLiteral("opEnvironText"));
        opEnvironText->setGeometry(QRect(790, 80, 131, 121));
        opEnvironText->setPixmap(QPixmap(QString::fromUtf8(":/images/plant.png")));
        opEnvironText->setScaledContents(true);
        stackedWidget->addWidget(operations);
        opEnvironGroup->raise();
        opDetectGroup->raise();
        opDisposalGroup->raise();
        opReturnMainButton->raise();
        opPageTitle->raise();
        RequestPamphlet = new QWidget();
        RequestPamphlet->setObjectName(QStringLiteral("RequestPamphlet"));
        RequestPamphlet->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        RPTextEdit = new QTextEdit(RequestPamphlet);
        RPTextEdit->setObjectName(QStringLiteral("RPTextEdit"));
        RPTextEdit->setGeometry(QRect(10, 10, 381, 81));
        RPTextEdit->setStyleSheet(QLatin1String("background: transparent;\n"
"border: 0px;"));
        RPTextEdit->setReadOnly(true);
        RPgroupBox = new QGroupBox(RequestPamphlet);
        RPgroupBox->setObjectName(QStringLiteral("RPgroupBox"));
        RPgroupBox->setGeometry(QRect(10, 110, 381, 301));
        RPgroupBox->setStyleSheet(QStringLiteral(""));
        RPCompanyNamelineEdit = new QLineEdit(RPgroupBox);
        RPCompanyNamelineEdit->setObjectName(QStringLiteral("RPCompanyNamelineEdit"));
        RPCompanyNamelineEdit->setGeometry(QRect(10, 30, 361, 31));
        RPCompanyNamelineEdit->setStyleSheet(QStringLiteral("background-color: white;"));
        RPCompanyNameLabel = new QLabel(RPgroupBox);
        RPCompanyNameLabel->setObjectName(QStringLiteral("RPCompanyNameLabel"));
        RPCompanyNameLabel->setGeometry(QRect(10, 10, 211, 20));
        QFont font1;
        font1.setPointSize(10);
        RPCompanyNameLabel->setFont(font1);
        RPAddressOneLineEdit = new QLineEdit(RPgroupBox);
        RPAddressOneLineEdit->setObjectName(QStringLiteral("RPAddressOneLineEdit"));
        RPAddressOneLineEdit->setGeometry(QRect(10, 110, 361, 31));
        RPAddressOneLineEdit->setStyleSheet(QStringLiteral("background-color: white;"));
        RPAddressTwoLineEdit = new QLineEdit(RPgroupBox);
        RPAddressTwoLineEdit->setObjectName(QStringLiteral("RPAddressTwoLineEdit"));
        RPAddressTwoLineEdit->setGeometry(QRect(10, 180, 361, 31));
        RPAddressTwoLineEdit->setStyleSheet(QStringLiteral("background-color: white;"));
        RPAddressL1Label = new QLabel(RPgroupBox);
        RPAddressL1Label->setObjectName(QStringLiteral("RPAddressL1Label"));
        RPAddressL1Label->setGeometry(QRect(10, 90, 191, 16));
        RPAddressL1Label->setFont(font1);
        RPAddressL2Label = new QLabel(RPgroupBox);
        RPAddressL2Label->setObjectName(QStringLiteral("RPAddressL2Label"));
        RPAddressL2Label->setGeometry(QRect(10, 160, 181, 16));
        RPAddressL2Label->setFont(font1);
        RPInterestcomboBox = new QComboBox(RPgroupBox);
        RPInterestcomboBox->addItem(QString());
        RPInterestcomboBox->addItem(QString());
        RPInterestcomboBox->addItem(QString());
        RPInterestcomboBox->addItem(QString());
        RPInterestcomboBox->addItem(QString());
        RPInterestcomboBox->setObjectName(QStringLiteral("RPInterestcomboBox"));
        RPInterestcomboBox->setGeometry(QRect(10, 250, 361, 31));
        RPInterestcomboBox->setStyleSheet(QStringLiteral("background-color: white;"));
        PRinterestLabel = new QLabel(RPgroupBox);
        PRinterestLabel->setObjectName(QStringLiteral("PRinterestLabel"));
        PRinterestLabel->setGeometry(QRect(10, 230, 181, 16));
        PRinterestLabel->setFont(font1);
        RPMainRequestPamphletButton = new QPushButton(RequestPamphlet);
        RPMainRequestPamphletButton->setObjectName(QStringLiteral("RPMainRequestPamphletButton"));
        RPMainRequestPamphletButton->setGeometry(QRect(260, 490, 121, 31));
        RPMainRequestPamphletButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        RPSubmitButton = new QPushButton(RequestPamphlet);
        RPSubmitButton->setObjectName(QStringLiteral("RPSubmitButton"));
        RPSubmitButton->setGeometry(QRect(50, 490, 151, 31));
        RPSubmitButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        label_3 = new QLabel(RequestPamphlet);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(400, 10, 581, 521));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/images/poster.jpg")));
        stackedWidget->addWidget(RequestPamphlet);
        CustomerViewer = new QWidget();
        CustomerViewer->setObjectName(QStringLiteral("CustomerViewer"));
        tableView = new QTableView(CustomerViewer);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 0, 681, 461));
        tableView->setStyleSheet(QStringLiteral("background-color: white;"));
        horizontalLayoutWidget_3 = new QWidget(CustomerViewer);
        horizontalLayoutWidget_3->setObjectName(QStringLiteral("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(0, 470, 921, 80));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_16 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_3->addWidget(pushButton_16);

        pushButton_11 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_3->addWidget(pushButton_11);

        pushButton_17 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_3->addWidget(pushButton_17);

        keyButton = new QPushButton(horizontalLayoutWidget_3);
        keyButton->setObjectName(QStringLiteral("keyButton"));
        keyButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_3->addWidget(keyButton);

        pushButton_12 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        horizontalLayout_3->addWidget(pushButton_12);

        verticalLayoutWidget = new QWidget(CustomerViewer);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(699, 6, 221, 451));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        label_4->setFont(font2);
        label_4->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout->addWidget(label_4);

        comboBox = new QComboBox(verticalLayoutWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        QFont font3;
        font3.setPointSize(8);
        comboBox->setFont(font3);
        comboBox->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout->addWidget(comboBox);

        label_5 = new QLabel(verticalLayoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font2);
        label_5->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout->addWidget(label_5);

        companyEdit = new QLineEdit(verticalLayoutWidget);
        companyEdit->setObjectName(QStringLiteral("companyEdit"));
        companyEdit->setFont(font3);
        companyEdit->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout->addWidget(companyEdit);

        label_6 = new QLabel(verticalLayoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setFont(font2);
        label_6->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout->addWidget(label_6);

        addressEdit = new QLineEdit(verticalLayoutWidget);
        addressEdit->setObjectName(QStringLiteral("addressEdit"));
        addressEdit->setFont(font3);
        addressEdit->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout->addWidget(addressEdit);

        label_7 = new QLabel(verticalLayoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setFont(font2);
        label_7->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout->addWidget(label_7);

        InterestEdit = new QLineEdit(verticalLayoutWidget);
        InterestEdit->setObjectName(QStringLiteral("InterestEdit"));
        InterestEdit->setFont(font3);
        InterestEdit->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout->addWidget(InterestEdit);

        label_8 = new QLabel(verticalLayoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setFont(font2);
        label_8->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout->addWidget(label_8);

        keyEdit = new QLineEdit(verticalLayoutWidget);
        keyEdit->setObjectName(QStringLiteral("keyEdit"));
        keyEdit->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout->addWidget(keyEdit);

        stackedWidget->addWidget(CustomerViewer);
        OrderViewer = new QWidget();
        OrderViewer->setObjectName(QStringLiteral("OrderViewer"));
        OrderViewer->setStyleSheet(QStringLiteral(""));
        OrderDetailGroupBox = new QGroupBox(OrderViewer);
        OrderDetailGroupBox->setObjectName(QStringLiteral("OrderDetailGroupBox"));
        OrderDetailGroupBox->setGeometry(QRect(604, 0, 281, 521));
        OrderDetailGroupBox->setStyleSheet(QStringLiteral(""));
        layoutWidget1 = new QWidget(OrderDetailGroupBox);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(14, 21, 261, 47));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        ovCompanyNameLabel = new QLabel(layoutWidget1);
        ovCompanyNameLabel->setObjectName(QStringLiteral("ovCompanyNameLabel"));
        ovCompanyNameLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        verticalLayout_2->addWidget(ovCompanyNameLabel);

        ovCompanyNameCombo = new QComboBox(layoutWidget1);
        ovCompanyNameCombo->setObjectName(QStringLiteral("ovCompanyNameCombo"));
        ovCompanyNameCombo->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout_2->addWidget(ovCompanyNameCombo);

        layoutWidget2 = new QWidget(OrderDetailGroupBox);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(15, 76, 261, 441));
        formLayout = new QFormLayout(layoutWidget2);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        OrderIDLabel = new QLabel(layoutWidget2);
        OrderIDLabel->setObjectName(QStringLiteral("OrderIDLabel"));
        OrderIDLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(0, QFormLayout::LabelRole, OrderIDLabel);

        ovOrderIDCombo = new QComboBox(layoutWidget2);
        ovOrderIDCombo->setObjectName(QStringLiteral("ovOrderIDCombo"));
        ovOrderIDCombo->setStyleSheet(QStringLiteral("background-color: white;"));

        formLayout->setWidget(0, QFormLayout::FieldRole, ovOrderIDCombo);

        RobotAQtyLabel = new QLabel(layoutWidget2);
        RobotAQtyLabel->setObjectName(QStringLiteral("RobotAQtyLabel"));
        RobotAQtyLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(1, QFormLayout::LabelRole, RobotAQtyLabel);

        ovRobotAQty = new QLineEdit(layoutWidget2);
        ovRobotAQty->setObjectName(QStringLiteral("ovRobotAQty"));
        ovRobotAQty->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotAQty->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotAQty->setReadOnly(true);

        formLayout->setWidget(1, QFormLayout::FieldRole, ovRobotAQty);

        RobotAPlanLabel = new QLabel(layoutWidget2);
        RobotAPlanLabel->setObjectName(QStringLiteral("RobotAPlanLabel"));
        RobotAPlanLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(2, QFormLayout::LabelRole, RobotAPlanLabel);

        ovRobotAPlan = new QLineEdit(layoutWidget2);
        ovRobotAPlan->setObjectName(QStringLiteral("ovRobotAPlan"));
        ovRobotAPlan->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotAPlan->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotAPlan->setReadOnly(true);

        formLayout->setWidget(2, QFormLayout::FieldRole, ovRobotAPlan);

        RibotBQtyLabel = new QLabel(layoutWidget2);
        RibotBQtyLabel->setObjectName(QStringLiteral("RibotBQtyLabel"));
        RibotBQtyLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(3, QFormLayout::LabelRole, RibotBQtyLabel);

        ovRobotBQty = new QLineEdit(layoutWidget2);
        ovRobotBQty->setObjectName(QStringLiteral("ovRobotBQty"));
        ovRobotBQty->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotBQty->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotBQty->setReadOnly(true);

        formLayout->setWidget(3, QFormLayout::FieldRole, ovRobotBQty);

        RobotBPlanLabel = new QLabel(layoutWidget2);
        RobotBPlanLabel->setObjectName(QStringLiteral("RobotBPlanLabel"));
        RobotBPlanLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(4, QFormLayout::LabelRole, RobotBPlanLabel);

        ovRobotBPlan = new QLineEdit(layoutWidget2);
        ovRobotBPlan->setObjectName(QStringLiteral("ovRobotBPlan"));
        ovRobotBPlan->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotBPlan->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotBPlan->setReadOnly(true);

        formLayout->setWidget(4, QFormLayout::FieldRole, ovRobotBPlan);

        RobotCQtyLabel = new QLabel(layoutWidget2);
        RobotCQtyLabel->setObjectName(QStringLiteral("RobotCQtyLabel"));
        RobotCQtyLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(5, QFormLayout::LabelRole, RobotCQtyLabel);

        ovRobotCQty = new QLineEdit(layoutWidget2);
        ovRobotCQty->setObjectName(QStringLiteral("ovRobotCQty"));
        ovRobotCQty->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotCQty->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotCQty->setReadOnly(true);

        formLayout->setWidget(5, QFormLayout::FieldRole, ovRobotCQty);

        RobotCPlanLabel = new QLabel(layoutWidget2);
        RobotCPlanLabel->setObjectName(QStringLiteral("RobotCPlanLabel"));
        RobotCPlanLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(6, QFormLayout::LabelRole, RobotCPlanLabel);

        ovRobotCPlan = new QLineEdit(layoutWidget2);
        ovRobotCPlan->setObjectName(QStringLiteral("ovRobotCPlan"));
        ovRobotCPlan->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotCPlan->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotCPlan->setReadOnly(true);

        formLayout->setWidget(6, QFormLayout::FieldRole, ovRobotCPlan);

        RobotASubLabel = new QLabel(layoutWidget2);
        RobotASubLabel->setObjectName(QStringLiteral("RobotASubLabel"));
        RobotASubLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(7, QFormLayout::LabelRole, RobotASubLabel);

        ovRobotASub = new QLineEdit(layoutWidget2);
        ovRobotASub->setObjectName(QStringLiteral("ovRobotASub"));
        ovRobotASub->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotASub->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotASub->setReadOnly(true);

        formLayout->setWidget(7, QFormLayout::FieldRole, ovRobotASub);

        RobotBSubLabel = new QLabel(layoutWidget2);
        RobotBSubLabel->setObjectName(QStringLiteral("RobotBSubLabel"));
        RobotBSubLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(8, QFormLayout::LabelRole, RobotBSubLabel);

        ovRobotBSub = new QLineEdit(layoutWidget2);
        ovRobotBSub->setObjectName(QStringLiteral("ovRobotBSub"));
        ovRobotBSub->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotBSub->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotBSub->setReadOnly(true);

        formLayout->setWidget(8, QFormLayout::FieldRole, ovRobotBSub);

        RobotCSubLabel = new QLabel(layoutWidget2);
        RobotCSubLabel->setObjectName(QStringLiteral("RobotCSubLabel"));
        RobotCSubLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(9, QFormLayout::LabelRole, RobotCSubLabel);

        ovRobotCSub = new QLineEdit(layoutWidget2);
        ovRobotCSub->setObjectName(QStringLiteral("ovRobotCSub"));
        ovRobotCSub->setStyleSheet(QStringLiteral("background-color: white;"));
        ovRobotCSub->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovRobotCSub->setReadOnly(true);

        formLayout->setWidget(9, QFormLayout::FieldRole, ovRobotCSub);

        SubtotalLabel = new QLabel(layoutWidget2);
        SubtotalLabel->setObjectName(QStringLiteral("SubtotalLabel"));
        SubtotalLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(10, QFormLayout::LabelRole, SubtotalLabel);

        ovSubtotal = new QLineEdit(layoutWidget2);
        ovSubtotal->setObjectName(QStringLiteral("ovSubtotal"));
        ovSubtotal->setStyleSheet(QStringLiteral("background-color: white;"));
        ovSubtotal->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovSubtotal->setReadOnly(true);

        formLayout->setWidget(10, QFormLayout::FieldRole, ovSubtotal);

        ShippingLabel = new QLabel(layoutWidget2);
        ShippingLabel->setObjectName(QStringLiteral("ShippingLabel"));
        ShippingLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(11, QFormLayout::LabelRole, ShippingLabel);

        ovShipping = new QLineEdit(layoutWidget2);
        ovShipping->setObjectName(QStringLiteral("ovShipping"));
        ovShipping->setStyleSheet(QStringLiteral("background-color: white;"));
        ovShipping->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovShipping->setReadOnly(true);

        formLayout->setWidget(11, QFormLayout::FieldRole, ovShipping);

        SalesTaxLabel = new QLabel(layoutWidget2);
        SalesTaxLabel->setObjectName(QStringLiteral("SalesTaxLabel"));
        SalesTaxLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(12, QFormLayout::LabelRole, SalesTaxLabel);

        ovSalesTax = new QLineEdit(layoutWidget2);
        ovSalesTax->setObjectName(QStringLiteral("ovSalesTax"));
        ovSalesTax->setStyleSheet(QStringLiteral("background-color: white;"));
        ovSalesTax->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovSalesTax->setReadOnly(true);

        formLayout->setWidget(12, QFormLayout::FieldRole, ovSalesTax);

        TotalPriceLabel = new QLabel(layoutWidget2);
        TotalPriceLabel->setObjectName(QStringLiteral("TotalPriceLabel"));
        TotalPriceLabel->setStyleSheet(QLatin1String("font-weight: bold;\n"
"color : white;"));

        formLayout->setWidget(13, QFormLayout::LabelRole, TotalPriceLabel);

        ovTotalPrice = new QLineEdit(layoutWidget2);
        ovTotalPrice->setObjectName(QStringLiteral("ovTotalPrice"));
        ovTotalPrice->setStyleSheet(QStringLiteral("background-color: white;"));
        ovTotalPrice->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        ovTotalPrice->setReadOnly(true);

        formLayout->setWidget(13, QFormLayout::FieldRole, ovTotalPrice);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(14, QFormLayout::LabelRole, verticalSpacer_10);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(14, QFormLayout::FieldRole, verticalSpacer_9);

        layoutWidget3 = new QWidget(OrderViewer);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(20, 20, 571, 491));
        gridLayout_5 = new QGridLayout(layoutWidget3);
        gridLayout_5->setSpacing(6);
        gridLayout_5->setContentsMargins(11, 11, 11, 11);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalSpacer_7 = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_5->addItem(verticalSpacer_7, 1, 1, 1, 1);

        verticalSpacer_15 = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_5->addItem(verticalSpacer_15, 1, 2, 1, 1);

        verticalSpacer_16 = new QSpacerItem(20, 18, QSizePolicy::Minimum, QSizePolicy::Fixed);

        gridLayout_5->addItem(verticalSpacer_16, 1, 3, 1, 1);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_8, 2, 0, 1, 1);

        ovSortByOrderIDButton = new QPushButton(layoutWidget3);
        ovSortByOrderIDButton->setObjectName(QStringLiteral("ovSortByOrderIDButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(ovSortByOrderIDButton->sizePolicy().hasHeightForWidth());
        ovSortByOrderIDButton->setSizePolicy(sizePolicy1);
        ovSortByOrderIDButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));

        gridLayout_5->addWidget(ovSortByOrderIDButton, 2, 1, 1, 1);

        ovSortByNameButton = new QPushButton(layoutWidget3);
        ovSortByNameButton->setObjectName(QStringLiteral("ovSortByNameButton"));
        sizePolicy1.setHeightForWidth(ovSortByNameButton->sizePolicy().hasHeightForWidth());
        ovSortByNameButton->setSizePolicy(sizePolicy1);
        ovSortByNameButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 175px;\n"
"border: 2px solid black;"));

        gridLayout_5->addWidget(ovSortByNameButton, 2, 2, 1, 1);

        ovReturnButton = new QPushButton(layoutWidget3);
        ovReturnButton->setObjectName(QStringLiteral("ovReturnButton"));
        sizePolicy1.setHeightForWidth(ovReturnButton->sizePolicy().hasHeightForWidth());
        ovReturnButton->setSizePolicy(sizePolicy1);
        ovReturnButton->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 175px;\n"
"border: 2px solid black;"));

        gridLayout_5->addWidget(ovReturnButton, 2, 3, 1, 1);

        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_9, 2, 4, 1, 1);

        ovTable = new QTableView(layoutWidget3);
        ovTable->setObjectName(QStringLiteral("ovTable"));
        ovTable->setStyleSheet(QStringLiteral("background-color: white;"));
        ovTable->horizontalHeader()->setDefaultSectionSize(150);
        ovTable->horizontalHeader()->setMinimumSectionSize(60);

        gridLayout_5->addWidget(ovTable, 0, 0, 1, 5);

        stackedWidget->addWidget(OrderViewer);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        page->setStyleSheet(QStringLiteral("background-color: #ccf2ff;"));
        label_23 = new QLabel(page);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(10, 20, 911, 81));
        QFont font4;
        font4.setFamily(QStringLiteral("Script"));
        font4.setPointSize(36);
        font4.setBold(false);
        font4.setItalic(false);
        font4.setWeight(50);
        label_23->setFont(font4);
        label_23->setStyleSheet(QStringLiteral("font: 36pt \"Script\" ;"));
        label_23->setAlignment(Qt::AlignCenter);
        pushButton_21 = new QPushButton(page);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(780, 480, 131, 31));
        pushButton_21->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        pushButton_18 = new QPushButton(page);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(180, 480, 93, 28));
        pushButton_18->setStyleSheet(QLatin1String("font-weight: bold;\n"
"font-size : 14px;\n"
"color : black;\n"
"background-color : #d6d6c2;\n"
"border-radius : 6px;\n"
"height : 25px;\n"
"width : 125px;\n"
"border: 2px solid black;"));
        groupBox_2 = new QGroupBox(page);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(480, 110, 431, 361));
        groupBox_2->setStyleSheet(QStringLiteral("background-color: white;"));
        verticalLayoutWidget_2 = new QWidget(groupBox_2);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(10, 10, 411, 341));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_10 = new QLabel(verticalLayoutWidget_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setFont(font1);

        verticalLayout_3->addWidget(label_10);

        label_11 = new QLabel(verticalLayoutWidget_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setFont(font1);

        verticalLayout_3->addWidget(label_11);

        label_13 = new QLabel(verticalLayoutWidget_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setFont(font1);

        verticalLayout_3->addWidget(label_13);

        label_14 = new QLabel(verticalLayoutWidget_2);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setFont(font1);

        verticalLayout_3->addWidget(label_14);

        label_12 = new QLabel(verticalLayoutWidget_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setFont(font1);

        verticalLayout_3->addWidget(label_12);

        layoutWidget4 = new QWidget(page);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(40, 100, 381, 371));
        verticalLayout_4 = new QVBoxLayout(layoutWidget4);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_9 = new QLabel(layoutWidget4);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setFont(font1);

        verticalLayout_4->addWidget(label_9);

        textEdit_2 = new QTextEdit(layoutWidget4);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setStyleSheet(QStringLiteral("background-color: white;"));

        verticalLayout_4->addWidget(textEdit_2);

        stackedWidget->addWidget(page);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 943, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        MainWindow->insertToolBarBreak(mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        QWidget::setTabOrder(CompanyNameLine, passwordLine);
        QWidget::setTabOrder(passwordLine, pushButton);
        QWidget::setTabOrder(pushButton, pushButton_2);
        QWidget::setTabOrder(pushButton_2, pushButton_4);

        retranslateUi(MainWindow);
        QObject::connect(pushButton, SIGNAL(released()), MainWindow, SLOT(adminLogin()));
        QObject::connect(pushButton_2, SIGNAL(released()), MainWindow, SLOT(customerLogin()));
        QObject::connect(pushButton_3, SIGNAL(released()), MainWindow, SLOT(logout()));
        QObject::connect(pushButton_4, SIGNAL(released()), MainWindow, SLOT(logout()));
        QObject::connect(pushButton_5, SIGNAL(released()), MainWindow, SLOT(viewProducts()));
        QObject::connect(pushButton_7, SIGNAL(released()), MainWindow, SLOT(contacts()));
        QObject::connect(pushButton_6, SIGNAL(released()), MainWindow, SLOT(viewGuarantee()));
        QObject::connect(pushButton_8, SIGNAL(released()), MainWindow, SLOT(help()));
        QObject::connect(pushButton_9, SIGNAL(released()), MainWindow, SLOT(requestPamphlet()));
        QObject::connect(pushButton_10, SIGNAL(released()), MainWindow, SLOT(viewCustomerList()));
        QObject::connect(pushButton_12, SIGNAL(released()), MainWindow, SLOT(adminLogin()));
        QObject::connect(comboBox, SIGNAL(currentIndexChanged(QString)), MainWindow, SLOT(populate()));
        QObject::connect(pushButton_16, SIGNAL(released()), MainWindow, SLOT(editCustomer()));
        QObject::connect(pushButton_11, SIGNAL(released()), MainWindow, SLOT(addCustomer()));
        QObject::connect(pushButton_17, SIGNAL(released()), MainWindow, SLOT(deleteCustomer()));
        QObject::connect(pushButton_20, SIGNAL(released()), MainWindow, SLOT(viewReviews()));
        QObject::connect(pushButton_21, SIGNAL(released()), MainWindow, SLOT(customerLogin()));
        QObject::connect(keyButton, SIGNAL(released()), MainWindow, SLOT(key()));
        QObject::connect(pushButton_18, SIGNAL(clicked()), textEdit_2, SLOT(clear()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label_15->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:28pt; font-weight:600;\">iRobots</span></p></body></html>", nullptr));
        groupBox->setTitle(QString());
        passwordLine->setText(QString());
        label->setText(QApplication::translate("MainWindow", "Company Name", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "Password", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "Customer Login", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "Request Pamphlet", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "  Admin Login  ", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "Contact Us", nullptr));
        helpLabel1->setText(QApplication::translate("MainWindow", "Click the \"Our Products\" Button to view and purchase the products we have for sale", nullptr));
        opButton->setText(QApplication::translate("MainWindow", "Operations", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "Guarantee", nullptr));
        helpLabel2->setText(QApplication::translate("MainWindow", "Click the \"Contact Us\" button to reach our team for further help ", nullptr));
        helpLabel5->setText(QApplication::translate("MainWindow", "Click the \"Logout\" button to logout and return to the login screen", nullptr));
        helpLabel6->setText(QApplication::translate("MainWindow", "Click the \"Operations\" button to view the details of our robots operating capabilities ", nullptr));
        helpLabel3->setText(QApplication::translate("MainWindow", "Click the \"Guarantee\" button to view our user guarantee", nullptr));
        helpLabel7->setText(QApplication::translate("MainWindow", "Clidk \"Customer Reviews\"  to see what our other satisfied customers are saying about us", nullptr));
        helpLabel4->setText(QApplication::translate("MainWindow", "Click the \"Help\" button again to hide the help options ", nullptr));
        pushButton_8->setText(QApplication::translate("MainWindow", "Help", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "Our Products", nullptr));
        pushButton_20->setText(QApplication::translate("MainWindow", "Customer reviews", nullptr));
        label_16->setText(QApplication::translate("MainWindow", "Welcome", nullptr));
        CompanyLabel->setText(QString());
        pitchWindow->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:18px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:120%;\"><span style=\" font-size:18pt; font-weight:600;\">iRobot</span></p>\n"
"<p align=\"center\" style=\" margin-top:16px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><span style=\" font-size:16pt; font-weight:600; color:#0055ff;\">Automating your future today</span><span style=\" font-size:12pt;\"> </span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><span"
                        " style=\" font-size:10pt;\">At iRobot work hard to provide robots for your bomb disposal needs. We offer a wide array of replacable electric friends able to complete the tasks that you don't want to.</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><span style=\" font-size:10pt;\">Our mechanical miracles move with majesty as they make your major issues minor in a minute. </span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><span style=\" font-size:10pt;\">We run our company with the utmost care for the people who are being protected by our products. This includes creating our products with the recycled materials of the earth.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:8px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%; font-"
                        "size:8pt;\"><br /></p>\n"
"<p align=\"center\" style=\" margin-top:16px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><img src=\"://images/wallelookingup.png\" width=\"200\" height=\"200\" style=\"float: right;\" /><span style=\" font-size:16pt; font-weight:600; color:#0055ff;\">About our products</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; line-height:100%;\"><span style=\" font-size:10pt;\">Our fleet of top of the line designs are avaible for purcahse today. We provide options that can traverse any terrain that you may come across. Along with this, all robots are able to remove bombs from many different locations such as airports, stores, and your own home! These robots use an IR sensor and a radioactive sensor to be able to detect bombs. This will even be able to detect bombs within a person.<br /></span></p></body></html>", nullptr));
        textEdit->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:36pt; color:#ffffff;\">Admin!</span></p></body></html>", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "View Customers", nullptr));
        viewOrdersAdminButton->setText(QApplication::translate("MainWindow", "View Orders", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "Logout", nullptr));
        opReturnMainButton->setText(QApplication::translate("MainWindow", "Return to Main Window", nullptr));
        opPageTitle->setText(QApplication::translate("MainWindow", "CONCEPT OF OPERATIONS", nullptr));
        opDisposalGroup->setTitle(QString());
        opDisposalImage->setText(QString());
        opDisposalText->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#0055ff;\">BOMB DISPOSAL</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">iRobots have compartments in their bodies for bomb disposal.<br />- The GO-4 is built to dispose of small explosive devices.<br />- The Eve is capable of disposing small to medium exposive devices.<br />- The Wall-E can dispose of small to large exposive devices.</span></p>\n"
"<p style=\"-qt-paragraph-type:em"
                        "pty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:7.8pt;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">** For more details, contact us.</span></p></body></html>", nullptr));
        opDetectGroup->setTitle(QString());
        opDetectText->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#0055ff;\">BOMB DETECTION</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">iRobots have laser sensors that scans and detects bombs.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The GO-4 can detect small exposive devices.</span></p>\n"
"<p style=\" margin-top"
                        ":0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The Eve is a multi-tasking detection iRobot capable of finding a wide variety of explosive devices.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The Wall-E has sensors in both eye for wider scans.</span></p></body></html>", nullptr));
        opDetectImage->setText(QString());
        opEnvironGroup->setTitle(QApplication::translate("MainWindow", "GroupBox", nullptr));
        opOneText->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt; font-weight:600; color:#0055ff;\">ENVIRONMENTS</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">iRobots are built to perform optimally within set environmental conditions.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The GO-4 is an indoor iRobot suitable for stairs and high maneuv"
                        "erability.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The Wall-E is built more rugged for outdoor conditions.  He can handle rocky, sandy, and muddy surfaces with incline and declines up to 25 degrees. </span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:7.8pt;\">- The Eve can be used in both indoor and outdoor conditions.  She can climb stairs and handle inclines and declines up to 45 degrees.</span></p></body></html>", nullptr));
        opEnvironImage->setText(QString());
        opEnvironText->setText(QString());
        RPTextEdit->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:16pt; font-weight:600; color:#397a75; vertical-align:sub;\"> Please fill in the fields below to request a pamphlet!</span></p></body></html>", nullptr));
        RPgroupBox->setTitle(QString());
        RPCompanyNameLabel->setText(QApplication::translate("MainWindow", "Company Name ", nullptr));
        RPAddressL1Label->setText(QApplication::translate("MainWindow", "Address Line 1", nullptr));
        RPAddressL2Label->setText(QApplication::translate("MainWindow", "Address Line2", nullptr));
        RPInterestcomboBox->setItemText(0, QString());
        RPInterestcomboBox->setItemText(1, QApplication::translate("MainWindow", "very interested", nullptr));
        RPInterestcomboBox->setItemText(2, QApplication::translate("MainWindow", "somewhat interested", nullptr));
        RPInterestcomboBox->setItemText(3, QApplication::translate("MainWindow", "not interested", nullptr));
        RPInterestcomboBox->setItemText(4, QApplication::translate("MainWindow", "never call again", nullptr));

        PRinterestLabel->setText(QApplication::translate("MainWindow", "Level of interest", nullptr));
        RPMainRequestPamphletButton->setText(QApplication::translate("MainWindow", "Main Menu", nullptr));
        RPSubmitButton->setText(QApplication::translate("MainWindow", "Submit Pamphlet ", nullptr));
        label_3->setText(QString());
        pushButton_16->setText(QApplication::translate("MainWindow", "Edit Selected", nullptr));
        pushButton_11->setText(QApplication::translate("MainWindow", "Add Customer", nullptr));
        pushButton_17->setText(QApplication::translate("MainWindow", "Delete Customer", nullptr));
        keyButton->setText(QApplication::translate("MainWindow", "Show Key", nullptr));
        pushButton_12->setText(QApplication::translate("MainWindow", "Back", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Select Customer", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "Company", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "Address", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Interest Level", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "Key", nullptr));
        OrderDetailGroupBox->setTitle(QString());
        ovCompanyNameLabel->setText(QApplication::translate("MainWindow", "Select Customer", nullptr));
        OrderIDLabel->setText(QApplication::translate("MainWindow", "Order ID", nullptr));
        RobotAQtyLabel->setText(QApplication::translate("MainWindow", "Robot A Qty", nullptr));
        RobotAPlanLabel->setText(QApplication::translate("MainWindow", "Robot A Plan", nullptr));
        RibotBQtyLabel->setText(QApplication::translate("MainWindow", "Robot B Qty", nullptr));
        RobotBPlanLabel->setText(QApplication::translate("MainWindow", "Robot B Plan", nullptr));
        RobotCQtyLabel->setText(QApplication::translate("MainWindow", "Robot C Qty", nullptr));
        RobotCPlanLabel->setText(QApplication::translate("MainWindow", "Robot C Plan", nullptr));
        RobotASubLabel->setText(QApplication::translate("MainWindow", "Robot A Subtotal: ", nullptr));
        RobotBSubLabel->setText(QApplication::translate("MainWindow", "Robot B Subtotal:", nullptr));
        RobotCSubLabel->setText(QApplication::translate("MainWindow", "Robot C Subtotal:", nullptr));
        SubtotalLabel->setText(QApplication::translate("MainWindow", "Subtotal:", nullptr));
        ShippingLabel->setText(QApplication::translate("MainWindow", "Shipping:", nullptr));
        SalesTaxLabel->setText(QApplication::translate("MainWindow", "Sales Tax:", nullptr));
        TotalPriceLabel->setText(QApplication::translate("MainWindow", "Total Price:", nullptr));
        ovSortByOrderIDButton->setText(QApplication::translate("MainWindow", "Sort by Order ID", nullptr));
        ovSortByNameButton->setText(QApplication::translate("MainWindow", "Sort by Company Name", nullptr));
        ovReturnButton->setText(QApplication::translate("MainWindow", "Return to Admin Menu", nullptr));
        label_23->setText(QApplication::translate("MainWindow", "Customer Reviews", nullptr));
        pushButton_21->setText(QApplication::translate("MainWindow", "Return to Menu", nullptr));
        pushButton_18->setText(QApplication::translate("MainWindow", "Submit", nullptr));
        groupBox_2->setTitle(QString());
        label_10->setText(QApplication::translate("MainWindow", "Making America safe! -CIA", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "We just say what the CIA says. It's great -FBI", nullptr));
        label_13->setText(QApplication::translate("MainWindow", "New robot servants to protect a robot? Great! -Zucc", nullptr));
        label_14->setText(QApplication::translate("MainWindow", "Love me some protection! -Jeff Bezos", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "Less annoying than people! -LAX", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "Any suggestions? Leave them down below", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
