# CS-c1-project1

repo for the first project for c1

![alt text](https://upload.wikimedia.org/wikipedia/commons/f/fa/Elephants_at_Amboseli_national_park_against_Mount_Kilimanjaro.jpg)

[![Waffle.io - Columns and their card count](https://badge.waffle.io/Jonjy/CS-c1-project1.svg?columns=all&logoColor=FF00F0)](https://waffle.io/Jonjy/CS-c1-project1)
[![User Stories Folder View](https://img.shields.io/badge/User%20Stories-Click%20Here%20to%20Edit-magenta.svg)](https://docs.google.com/document/d/1aGkrYf6z4p1RcXLLSSPg9AkM0_HcnYT8FyJrp0zgK_A/edit?usp=sharing)

[![Artifacts Folder](https://img.shields.io/badge/Artifacts-Click%20here%20to%20view%20folder%20-purple.svg)](https://drive.google.com/drive/folders/1k4THpVhGVOyMag9B0azLtj3kBvJXkrwO?usp=sharing)  [![SQLite](https://img.shields.io/badge/SQL-Click%20here%20to%20view%20tutorial%20-blue.svg)](https://www.tutorialspoint.com/sqlite/index.htm)
db browser 
